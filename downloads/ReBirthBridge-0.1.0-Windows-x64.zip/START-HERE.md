# ReBirth Bridge — Windows VST3 prototype

ReBirth Bridge 0.1.0 receives the original Windows ReBirth application's stereo
output through a virtual audio cable and optionally sends Cubase's tempo,
MIDI Clock, Start and Stop through a virtual MIDI port. It is a 64-bit VST3
instrument, not a port of ReBirth. ReBirth runs separately with its own window.
No ReBirth executable, samples, Mac port code or proprietary ReWire SDK is included.

This is an experimental first milestone. Windows binary loading, the native editor and VST3 interface
validation have passed under Wine; actual ReBirth / Cubase 15 audio, clock
compatibility and Windows 11 device behavior require testing on the user's PC.

## Try it in Cubase 15 / Windows 11

1. Install a virtual audio cable if you do not have one. A common choice is
   [VB-CABLE from VB-Audio](https://vb-audio.com/Cable/). Follow the vendor's driver
   installation instructions and restart Windows if requested. Your existing
   virtual MIDI port can be used; create one named `ReBirth Sync` if needed.
2. Close Cubase. Extract the release ZIP. Copy the **whole `ReBirthBridge.vst3`
   folder** into `C:\Program Files\Common Files\VST3\`. Windows may request
   administrator permission for this copy. Keep its `Contents` folder intact.
3. Start ReBirth normally. In its audio preferences choose the **playback** side
   of the cable, usually `CABLE Input (VB-Audio Virtual Cable)`, using its MME
   driver if available. Set ReBirth to 44,100 Hz. Play a pattern manually.
4. Start Cubase, let it scan the plugin, and add an instrument track with
   **ReBirth Bridge**. Keep Cubase using your normal audio interface/ASIO driver.
   Open the plugin editor, choose **CABLE Output** as the audio input, leave MIDI
   disabled for this first check, and click **Connect / Retry**. Ensure the
   instrument track is enabled/monitored and its output reaches Stereo Out.
5. Confirm the plugin reports **Audio: connected** and you hear the ReBirth
   pattern through Cubase. The first goal is audio, before synchronization.
6. Stop ReBirth. Select your virtual MIDI port as ReBirth's MIDI input and enable
   its external MIDI synchronization. Select the same port in the bridge's MIDI
   output selector and click **Connect / Retry**. Play Cubase from the beginning.
   The bridge sends MIDI Start plus 24 MIDI clocks per quarter note at the host's
   tempo. Stop Cubase to send MIDI Stop.
7. Save the ReBirth song in ReBirth, and the Cubase project separately. The bridge
   remembers selected device names in the Cubase project, not ReBirth's song.

Cable naming is counterintuitive: ReBirth **plays into CABLE Input**; the bridge
**records from CABLE Output**. Do not select your microphone. Do not turn on
Windows "Listen to this device"; that can duplicate monitoring or create feedback.

The **Launch ReBirth...** button opens a file picker for your existing ReBirth
executable or launcher. It is optional: manually launching ReBirth is fine. The
bridge does not terminate ReBirth when removed and does not embed its window.

## Current limits

- Use **one bridge instance and one ReBirth instance**. Device drivers and the
  old application may not support multiple clients. Avoid multiple MIDI clock
  senders on the same virtual port; this bridge supplies clock, so don't also
  configure Cubase to send its own clock to that port.
- Audio capture uses Windows MME at stereo PCM16 / 44,100 Hz. The bridge resamples
  to the Cubase project rate, with a small adaptive adjustment for clock drift.
  The interpolation is suitable for proving the connection, not a final mastering
  resampler. Start testing with a 44.1 kHz Cubase project.
- The capture buffer targets about 23 ms, in addition to cable, ReBirth and host
  buffering. Actual latency varies and is **not automatically compensated**.
  Measure and manually align recorded audio if needed.
- MIDI uses a worker thread and a 1 ms timer request, not sample-accurate scheduling.
  Windows scheduling, the virtual port, and ReBirth may add jitter. Clock stops
  after 300 ms without host processing callbacks. Cubase suspension may therefore
  stop ReBirth. Arm/monitor the track while testing.
- Each play transition sends **Start from the song beginning**, not Continue or
  Song Position Pointer. Seek, Cubase cycle/loop alignment and position recall
  are not implemented. Test with cycle mode off and playback from the beginning.
- No MIDI note/CC forwarding, parameter automation, individual drum outputs or
  ReBirth song-state embedding yet. The host event input is reserved and ignored.
- **Real-time playback/export only.** Offline/faster-than-real-time processing
  deliberately outputs silence and stops clock. Do not use offline Render in
  Place, Freeze, or export for this instrument.
- Device names use the legacy WinMM names, which can be truncated. If you have
  multiple devices with identical names, avoid relying on automatic recall and
  select/check the device again. Device lists refresh when the editor is reopened.
- The prototype is unsigned. It makes no changes to your ReBirth installation.

## Troubleshooting / what to report

First test **audio only**, with MIDI disabled and ReBirth playing manually.

- `Audio: driver error`: copy the displayed error; close other software holding
  the cable, check the cable supports stereo 16-bit 44.1 kHz, then Connect / Retry.
- `Audio: disabled / inactive`: choose a capture input and connect; confirm the
  Cubase track is enabled and processing. Project recall with a missing device
  falls back to disabled.
- Connected but silent: check the two cable ends, the ReBirth audio output,
  Cubase track output/mute/monitoring, and Windows 11 microphone privacy settings
  allowing desktop applications to capture audio.
- Increasing rebuffer or dropped-frame counters: report both counters, the Cubase
  sample rate/buffer size and the selected devices. The counters include startup
  buffering; a few at startup are expected.
- Audio works but sync does not: report the MIDI port name and ReBirth's sync
  setting. Confirm no other application sends clock on the port. Try Cubase at
  120 BPM, cycle off, starting from the beginning.
- Plugin missing: verify the entire bundle is installed under the VST3 folder,
  restart Cubase and inspect VST Plug-in Manager. If it is blocklisted, report
  that before repeatedly rescanning it.

## Build from source

Requirements: CMake >= 3.25, C++17, and either Visual Studio 2022 C++ desktop tools
on Windows or MinGW-w64 x86-64 with its POSIX runtime on Linux. Python 3 is used
only for packaging. The pinned Steinberg SDK is MIT licensed.

From the repository root (PowerShell on Windows):

```powershell
git clone --no-checkout https://github.com/steinbergmedia/vst3sdk.git deps/vst3sdk
git -C deps/vst3sdk checkout 9fad9770f2ae8542ab1a548a68c1ad1ac690abe0
git -C deps/vst3sdk submodule update --init --depth 1 base cmake pluginterfaces public.sdk
cmake -S . -B build -A x64 -DVST3_SDK_ROOT="$PWD/deps/vst3sdk" -DBUILD_TESTING=ON
cmake --build build --config Release --target ReBirthBridge bridge-core-tests
ctest --test-dir build -C Release --output-on-failure
```

On Linux with MinGW-w64 installed:

```sh
cmake -S . -B build-tests -DRB_BUILD_PLUGIN=OFF -DCMAKE_BUILD_TYPE=Release
cmake --build build-tests -j 3
ctest --test-dir build-tests --output-on-failure
cmake -S . -B build-windows -DCMAKE_TOOLCHAIN_FILE=cmake/mingw.cmake \
  -DVST3_SDK_ROOT=/absolute/path/to/vst3sdk -DCMAKE_BUILD_TYPE=Release \
  -DBUILD_TESTING=OFF
cmake --build build-windows --target ReBirthBridge validator -j 3
python3 scripts/package.py --binary build-windows/VST3/ReBirthBridge.vst3 \
  --sdk /absolute/path/to/vst3sdk
```

The cross build emits a flat Windows DLL; packaging places it in the standard
`ReBirthBridge.vst3/Contents/x86_64-win/ReBirthBridge.vst3` bundle. The SDK's unused
Data Exchange implementation is excluded for MinGW because SDK 3.8 uses an
allocation API MinGW does not provide. The SDK itself is not patched. Cross
builds do not run Windows programs automatically or claim validator success.

Run the SDK Windows validator against the **packaged bundle** on Windows:

```powershell
.\build\bin\Release\validator.exe "C:\path\to\ReBirthBridge.vst3"
```

Check its final passed/failed counts, not just exit status. On Windows-native
builds the SDK also runs its validator after building the plugin.

Portable core tests exercise FIFO bounds, wraparound, concurrent producer/consumer
transfer, sample-rate conversion, underruns, backlog trimming and MIDI clock /
transport scheduling. These do not establish hardware-driver or DAW compatibility.

## Cloud development

The existing checkout is `/workspace/rb338`; cloud tasks are isolated already.
Do not create another Git worktree. `scripts/setup-cloud.sh` installs tools into
`/workspace/toolchain`, retains the pinned SDK in `/workspace/deps/vst3sdk`, runs
core tests, builds Windows artifacts, and packages the result without root access.
See `VALIDATION.md` for the actual checks completed on the current prototype.
