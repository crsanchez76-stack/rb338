# Validation of ReBirth Bridge 0.1.0

This report concerns the Windows x86-64 prototype built in the Linux cloud
workspace. It does not establish compatibility with Cubase 15 or ReBirth on a
physical Windows 11 machine.

## Completed

- Cross-compiled the Windows VST3 DLL using MinGW-w64 GCC 14 POSIX and the pinned
  Steinberg VST3 SDK 3.8.0 commit listed in README.md.
- Portable C++ core tests: **32 checks passed**. Includes full/empty FIFO bounds,
  wraparound, 500,000 stereo frames exchanged concurrently, resampling ratio and
  channel separation, silence on underrun, latency-backlog trimming, MIDI clock
  rate, Start/Stop transitions and scheduling-stall handling.
- Steinberg **Windows** VST3 validator executed through Wine 10 against the final
  packaged bundle: **47 tests passed, 0 failed; exit code 0**. The bundle structure
  passed. Tests included both 32-bit and 64-bit sample processing, variable block
  sizes, suspend/resume, buses and processing-thread use, with capture disabled.
  Optional MIDI mapping, note expression, automation and unit interfaces are
  absent; the validator reports these as not provided. Its process-format probe
  logs rejected sample rates below 8 kHz and above 384 kHz; those are intentionally
  unsupported and the runner's process-format tests passed.
- A separate Windows host smoke test, through Wine with Xvfb: **48 checks passed;
  exit code 0**. Loaded DLL exports, instantiated and connected processor/controller,
  opened the real Win32 editor, located selectors, clicked Connect with devices
  disabled, processed 20 silent audio blocks, round-tripped the 260-byte device
  state, removed the editor, deactivated and unloaded the plugin.
- Verified DLL imports use Windows system libraries only; no separate MinGW
  runtime DLLs are required. The binary is Windows PE x86-64 and exports
  `GetPluginFactory`, `InitDll`, and `ExitDll`.
- Ran `scripts/setup-cloud.sh` against the prepared machine successfully to verify
  repeatability of configuration, tests, build and packaging. A brand-new machine
  restoration has not been tested. No environment publication is claimed.

Logs are in `build-windows/validation/`. Re-run the prepared Wine checks with:

```sh
python3 scripts/validate-wine.py
```

Wine and Xvfb were extracted from signed Debian repository packages into
`/workspace/toolchain`; no system installation or verification bypass was used.
The local Wine package layout needed a relative wineserver launcher, a data-path
symlink, and the package-supplied x86-64 `zlib1.dll` in its test prefix. This is
build-machine configuration only and is not bundled or needed on Windows.

## Still needs testing on Windows 11 / Cubase 15

- Cubase discovery, editor rendering, focus and DPI behavior.
- ReBirth MME output -> virtual cable -> plugin input -> Cubase stereo output.
- Actual audio fidelity, buffering, long-run clock drift and measured latency.
- Virtual MIDI driver's multi-client behavior and ReBirth response to clock,
  Start and Stop, including tempo changes.
- Cubase project close/reopen with real selected devices and real-time export.

The Mac upload was examined for format clues only. No Mac executable code or
ReBirth content was used in this prototype. No real ReBirth audio or MIDI driver
connection has been tested in the cloud.
