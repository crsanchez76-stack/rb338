# Validation of ReBirth Bridge 0.1.2

This report concerns the Windows x86-64 prototype built in the Linux cloud
workspace. It does not establish compatibility with Cubase 15 or ReBirth on a
physical Windows 11 machine.

## Completed

- Cross-compiled the Windows VST3 DLL using MinGW-w64 GCC 14 POSIX and the pinned
  Steinberg VST3 SDK 3.8.0 commit listed in README.md.
- Portable C++ core tests: **92 checks passed**. Includes full/empty FIFO bounds,
  wraparound, 500,000 stereo frames exchanged concurrently, resampling ratio and
  channel separation, silence on underrun, latency-backlog trimming, MIDI clock
  rate, Start/Stop transitions and scheduling-stall handling. Additional regression
  checks cover clock continuation after Stop, explicit manual Stop with restart
  inhibition and rapid host stop/play signaling. Burst-capture regressions exercise
  256-, 1024- and 2048-frame delivery batches, a 128-sample host buffer, both 44.1
  and 48 kHz host rates, and +/-200 ppm clock drift over 8000 blocks per case.
  They require continuous output after startup, no trimming of normal bursts,
  finite stereo samples and a bounded queue. Near-full backlog recovery is also
  tested separately.
- Steinberg **Windows** VST3 validator executed through Wine 10 against the final
  packaged bundle: **47 tests passed, 0 failed; exit code 0**. The bundle structure
  passed. Tests included both 32-bit and 64-bit sample processing, variable block
  sizes, suspend/resume, buses and processing-thread use, with capture disabled.
  Optional MIDI mapping, note expression, automation and unit interfaces are
  absent; the validator reports these as not provided. Its process-format probe
  logs rejected sample rates below 8 kHz and above 384 kHz; those are intentionally
  unsupported and the runner's process-format tests passed.
- A separate Windows host smoke test, through Wine with Xvfb: **50 checks passed;
  exit code 0**. Loaded DLL exports, instantiated and connected processor/controller,
  opened the real Win32 editor, located selectors, clicked Connect with devices
  disabled, found/clicked the new manual Stop control, processed 20 silent audio blocks, round-tripped the 260-byte device
  state, removed the editor, deactivated and unloaded the plugin.
- Verified DLL imports use Windows system libraries only; no separate MinGW
  runtime DLLs are required. The binary is Windows PE x86-64 and exports
  `GetPluginFactory`, `InitDll`, and `ExitDll`.
- Ran `scripts/setup-cloud.sh` against the prepared machine successfully to verify
  repeatability of configuration, tests, build and packaging. A brand-new machine
  restoration has not been tested. No environment publication is claimed.

Logs are in `build-windows/validation/`. Re-run the prepared Wine checks with:

```sh
python3 scripts/validate-wine.py
```

Wine and Xvfb were extracted from signed Debian repository packages into
`/workspace/toolchain`; no system installation or verification bypass was used.
The local Wine package layout needed a relative wineserver launcher, a data-path
symlink, and the package-supplied x86-64 `zlib1.dll` in its test prefix. This is
build-machine configuration only and is not bundled or needed on Windows.

## User-reported baseline and remaining Windows checks

The user tested 0.1.0 on Windows 11 / Cubase 15: ReBirth audio reached Cubase and
Cubase Start started ReBirth. They reported severe latency and no response to
Stop. This confirms the basic connection, not acceptable latency or transport.

The user subsequently tested 0.1.1 and confirmed Stop now works. Audio was very
crackly at 69 ms DirectX play-ahead / 128-sample Cubase buffer. Rebuffered-block
and dropped-capture-frame counters were stable, but trimmed-frame counts rose
continuously. The user had aligned playback with a 151 ms ReBirth Adjust Sync
setting. That compensates timing, not live interaction latency.

Version 0.1.2 retains the Stop implementation, restores eight 256-frame capture
buffers, raises the minimum queue reserve to 1024 frames, adapts to the observed
capture batch size, smooths drift feedback, and removes the low normal-burst trim
threshold. Trimming is reserved for near-full queues after a long interruption.
This directly addresses a likely source of discontinuities. Actual crackle
resolution and new sync offset on the user's Windows machine are **not yet
verified**. The tested changes trade some buffering latency for stability.

Still needs testing on Windows 11 / Cubase 15:

- Cubase discovery, editor rendering, focus and DPI behavior.
- ReBirth MME output -> virtual cable -> plugin input -> Cubase stereo output.
- Actual audio fidelity, buffering, long-run clock drift and measured latency.
- Virtual MIDI driver's multi-client behavior and ReBirth response to clock,
  Start and Stop, including tempo changes.
- Cubase project close/reopen with real selected devices and real-time export.

The Mac upload was examined for format clues only. No Mac executable code or
ReBirth content was used in this prototype. No real ReBirth audio or MIDI driver
connection has been tested in the cloud.
